import styled from 'styled-components';

export const StyledHeading = styled.h1`
  margin: 20px 0;
`