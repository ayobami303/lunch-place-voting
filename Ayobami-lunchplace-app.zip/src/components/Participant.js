import React from 'react';

function Participant({name}) {
  return (
    <p className="mb-0">{name}</p>
  )
}

export default Participant;